"""Independent R5 targeted review. Run from the detached review clone root."""
import hashlib
import json
import pathlib
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
E = ROOT / 'final-r5-evidence'
BASE = 'aaa74afb3c264bbd7ca43555a7445c77994ccaa2'
CONTENT = '719c3fbbe4db1a4dfa0f9d324c3a376f885f47e5'
FREEZE = 'b58dfff04b484f2ed15524d51883e5f979fd1bc1'
R4 = '63b24fc14c728af03b1089c864bab95c5bfa8d9b'
PRE = '294b7c72317a4bc761515eba31692169cd795f81'
TIP = '15771815c016af66d064e5f4d66dc1dbc6b0a74a'
commands = []

def sha(data):
    return hashlib.sha256(data).hexdigest()

def save(name, data):
    (E / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

def run(argv, cwd=ROOT):
    r = subprocess.run(argv, cwd=cwd, capture_output=True)
    record = {'command': [str(x) for x in argv], 'cwd': str(cwd), 'exit': r.returncode,
              'stdout': r.stdout.decode('utf-8', errors='replace'), 'stderr': r.stderr.decode('utf-8', errors='replace')}
    commands.append(record)
    return record

def git(*args):
    return run(['git', *args])

assert git('rev-parse', 'HEAD')['stdout'].strip() == TIP
assert git('status', '--porcelain', '--untracked-files=no')['stdout'] == ''
scope = {'identity': {}, 'ancestors': [], 'diffs': {}}
for label, value in [('base', BASE), ('content', CONTENT), ('freeze', FREEZE), ('r4', R4), ('pre', PRE), ('tip', TIP)]:
    check = git('cat-file', '-e', value + '^{commit}')
    assert check['exit'] == 0
    scope['identity'][label] = value
chain = [BASE, CONTENT, FREEZE, R4, PRE, TIP]
for a, b in zip(chain, chain[1:]):
    r = git('merge-base', '--is-ancestor', a, b)
    assert r['exit'] == 0
    scope['ancestors'].append({'from': a, 'to': b, 'exit': r['exit']})
for name, start, paths in [('runtime', CONTENT, ['include', 'src', 'tests', 'examples', 'CMakeLists.txt', 'cmake']),
                           ('benchmark', R4, ['benchmarks']), ('schema', R4, ['schema', 'schemas']),
                           ('docs_preliminary', R4, [])]:
    end = PRE if name == 'docs_preliminary' else TIP
    r = git('diff', '--name-only', start, end, '--', *paths)
    assert r['exit'] == 0
    scope['diffs'][name] = r['stdout'].splitlines()
    if name != 'docs_preliminary':
        assert r['stdout'] == ''
scope['diffs']['repair_delta'] = git('diff', '--name-only', PRE, TIP)['stdout'].splitlines()
scope['development_before'] = run(['git', 'status', '--porcelain=v1', '-b'], ROOT.parent / 'solver_database_v2')
scope['development_head'] = run(['git', 'rev-parse', 'HEAD'], ROOT.parent / 'solver_database_v2')
scope['development_remote'] = run(['git', 'remote', '-v'], ROOT.parent / 'solver_database_v2')
assert scope['development_head']['stdout'].strip() == TIP
save('scope.json', scope)

tracked = ROOT / 'verification/reviews/B01/task-evidence/identity-controls.json'
original = tracked.read_bytes()
try:
    formal = run([sys.executable, 'verification/reviews/B01/task-evidence/identity-controls.py'])
    replay = tracked.read_bytes()
    (E / 'official-controls-replay.json').write_bytes(replay)
    (E / 'official-controls.log').write_text(formal['stdout'] + formal['stderr'], encoding='utf-8')
    original_data = json.loads(original)
    replay_data = json.loads(replay)
    official = {'exit': formal['exit'], 'count': len(replay_data), 'all_fields_equal': original_data == replay_data,
                'original_sha256': sha(original), 'replay_sha256': sha(replay),
                'passed': sum(c['expected_exit'] == c['actual_exit'] and c.get('diagnostic_matches', True) for c in replay_data)}
finally:
    tracked.write_bytes(original)
official['tracked_bytes_restored'] = tracked.read_bytes() == original
save('official-controls-check.json', official)
assert official['exit'] == 0 and official['all_fields_equal'] and official['passed'] == official['count'] == 50

def validate(path, expected, diagnostic=''):
    r = run([sys.executable, str(ROOT / 'verification/validate_batch_identity.py'), str(path), '--git-dir', str(ROOT),
             '--expect-base', BASE, '--expect-head', CONTENT, '--expect-freeze', FREEZE])
    return {'expected_exit': expected, 'actual_exit': r['exit'], 'expected_diagnostic': diagnostic,
            'output': r['stdout'] + r['stderr'], 'command': r['command'],
            'pass': r['exit'] == expected and diagnostic in (r['stdout'] + r['stderr'])}

old_dir = ROOT.parent / 'sdb-review-b01-r4-handoff/reports/merged-r4-evidence'
old_json = old_dir / 'adversarial-identity.json'
old_cases = json.loads(old_json.read_bytes())
replayed = []
for case in old_cases:
    path = old_dir / pathlib.Path(case['manifest']).name
    data = path.read_bytes()
    assert sha(data) == case['manifest_sha256']
    dest = E / path.name
    dest.write_bytes(data)
    result = validate(dest, case['expected_exit'])
    result.update({'case': case['case'], 'source': str(path), 'fixture_sha256': sha(data),
                   'original_expected_exit': case['expected_exit'], 'previous_actual_exit': case['actual_exit']})
    replayed.append(result)
save('original-r4-replay.json', {'source_json': str(old_json), 'source_json_sha256': sha(old_json.read_bytes()), 'cases': replayed})
assert len(replayed) == 26 and all(c['pass'] for c in replayed)

minimal = f'batch_base_sha: {BASE}\nbatch_content_head_sha: {CONTENT}\nfreeze_packet_sha: {FREEZE}\n'
extra = []
def case(name, text, expected, diagnostic=''):
    path = E / (name + '.yaml')
    path.write_bytes(text.encode('utf-8'))
    r = validate(path, expected, diagnostic)
    r.update({'case': name, 'fixture_sha256': sha(path.read_bytes()), 'manifest': str(path)})
    extra.append(r)

unsupported = 'unsupported quoted key syntax'
for name, line in [
    ('escaped-doublequote-leading', r'"\"freeze_packet_sha": bad'),
    ('escaped-doublequote-trailing', r'"freeze_packet_sha\"": bad'),
    ('escaped-backslash', r'"unknown\\key": ignored'),
    ('incomplete-hex', r'"batch_content_head_\x7": bad'),
    ('incomplete-long-unicode', r'"\U0000006": bad'),
    ('trailing-backslash', '"freeze_packet_sha\\'),
    ('unknown-double-unclosed', '"metadata: ignored'),
    ('unknown-single-unclosed', "'metadata: ignored"),
    ('quotes-mismatched', "\"freeze_packet_sha': bad"),
    ('after-close-garbage', '"freeze_packet_sha"suffix: bad'),
    ('missing-key-colon', '"freeze_packet_sha" bad'),
    ('empty-doublequoted', '"": ignored'),
    ('empty-singlequoted', "'': ignored"),
    ('singlequote-doubled-unsupported', "'meta''data': ignored"),
]:
    case('r5-' + name, minimal + line + '\n', 1, unsupported)
case('r5-escaped-key-before-identities', r'"\u0066reeze_packet_sha": invalid' + '\n' + minimal, 1, unsupported)
case('r5-unknown-ordinary-double', minimal + '"metadata": ignored\n', 0, 'IDENTITY OK')
case('r5-unknown-ordinary-single', minimal + "'metadata': ignored\n", 0, 'IDENTITY OK')
case('r5-unknown-single-literal-escape', minimal + "'batch_content_head_\\x73ha': ignored\n", 0, 'IDENTITY OK')
case('r5-single-literal-only-missing', minimal.replace('freeze_packet_sha:', "'\\u0066reeze_packet_sha':"), 1, 'missing required identity field(s): freeze_packet_sha')
case('r5-quoted-key-backslash-value', minimal + '"metadata": "C:\\folder"\n', 0, 'IDENTITY OK')
case('r5-quoted-key-colon-inside', minimal + '"meta:data": ignored\n', 0, 'IDENTITY OK')
case('r5-quoted-key-other-quote', minimal + '"meta\'data": ignored\n', 0, 'IDENTITY OK')
case('r5-single-key-double-quote', minimal + "'meta\"data': ignored\n", 0, 'IDENTITY OK')
case('r5-comment-escaped-key', minimal + '# "\\u0066reeze_packet_sha": invalid\n', 0, 'IDENTITY OK')
case('r5-nested-escaped-key', minimal + 'notes: |\n  "\\u0066reeze_packet_sha": invalid\n', 0, 'IDENTITY OK')
for key, value in [('batch_base_sha', BASE), ('batch_content_head_sha', CONTENT), ('freeze_packet_sha', FREEZE)]:
    quoted = minimal.replace(key + ':', '"' + key + '"\t:')
    case('r5-quoted-tab-valid-' + key, quoted, 0, 'IDENTITY OK')
    case('r5-quoted-then-bare-duplicate-' + key, quoted + key + ': ' + value + '\n', 1, 'duplicate identity key')
    case('r5-mixedquote-duplicate-' + key, quoted + "'" + key + "': invalid\n", 1, 'duplicate identity key')
save('independent-controls.json', extra)
assert all(c['pass'] for c in extra)

prov_text = (ROOT / 'verification/reviews/B01/report-provenance.md').read_text(encoding='utf-8')
provenance = []
for row in prov_text.splitlines():
    if not row.startswith('| ') or '/reports/' not in row:
        continue
    cells = row.split('|')
    source = ROOT.parent / cells[2].strip().strip('`')
    expected_size, raw_hash = cells[3].strip().split(' / ')
    raw_hash = raw_hash.strip('`')
    blob_hash = cells[4].strip().strip('`')
    copy_name = source.name
    # First-round reports retain their original names; all six can be located uniquely.
    matches = list((ROOT / 'verification/reviews/B01').glob(copy_name))
    if not matches:
        copy_name = {'astra-batch-review.md': 'astra-review.md', 'opus-batch-review.md': 'opus-review.md'}[copy_name]
    blob_path = 'verification/reviews/B01/' + copy_name
    raw = source.read_bytes()
    blob = subprocess.run(['git', 'show', TIP + ':' + blob_path], cwd=ROOT, capture_output=True, check=True).stdout
    rec = {'source': str(source), 'blob': TIP + ':' + blob_path, 'raw_size': len(raw), 'raw_sha256': sha(raw), 'blob_sha256': sha(blob),
           'raw_matches': len(raw) == int(expected_size) and sha(raw) == raw_hash,
           'blob_matches': sha(blob) == blob_hash, 'lf_normalized_equal': raw.replace(b'\r\n', b'\n') == blob}
    provenance.append(rec)
save('provenance-check.json', provenance)
assert len(provenance) == 6 and all(c['raw_matches'] and c['blob_matches'] and c['lf_normalized_equal'] for c in provenance)

for file in ['verification/validate_batch_identity.py', 'docs/development/SESSION_HANDOFF.md',
             'docs/development/CONTINUOUS_STATUS.md', 'docs/development/BATCH_HISTORY.md']:
    lines = (ROOT / file).read_text(encoding='utf-8').splitlines()
    dest = E / (pathlib.Path(file).name + '.numbered.txt')
    dest.write_text('\n'.join(f'{i}: {line}' for i, line in enumerate(lines, 1)) + '\n', encoding='utf-8')
final = {'official_passed': official['passed'], 'original_r4_passed': sum(c['pass'] for c in replayed),
         'independent_passed': sum(c['pass'] for c in extra), 'independent_count': len(extra),
         'provenance_pairs': len(provenance), 'tracked_status': git('status', '--porcelain', '--untracked-files=no'),
         'development_after': run(['git', 'status', '--porcelain=v1', '-b'], ROOT.parent / 'solver_database_v2'),
         'development_head_after': run(['git', 'rev-parse', 'HEAD'], ROOT.parent / 'solver_database_v2')}
assert final['tracked_status']['stdout'] == ''
assert final['development_head_after']['stdout'].strip() == TIP
save('final-checks.json', final)
save('commands.json', commands)
print(json.dumps(final, indent=2))
